#!/usr/bin/python                                          
                                                                                                
import csv
import sys
reader = csv.reader(sys.stdin, delimiter='\t')
next(reader)

for line in reader: 
    userid, placeid, datetime, lat, lon, city, category=line
    word=userid,placeid,lat,lon,category
    print(word,1 )
