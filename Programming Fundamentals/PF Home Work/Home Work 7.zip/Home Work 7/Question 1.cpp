#include <iostream>

using namespace std;

int main()
{

    int x;

    cout<<"\nEnter Value between ranges \n\t 1 to 4\n\t 5 to 7\n\t 8 to 10";
    cin>>x;


    switch(x)
    {
        case 1 ... 4:

          cout<<"1 . . . 4";
          break;

        case 5 ... 7:
          cout<<"5 . . . 7";
          break;

        case 8 ... 10:
          cout<<"8 . . . 10"; 
          break;

        default:
          cout<<"wrong input";

    }
    return 0;
} 







