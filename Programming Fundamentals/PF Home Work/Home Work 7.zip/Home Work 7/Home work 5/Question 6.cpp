#include <iostream>

using namespace std;

int main ()
{
     int per;
     cout << "\nEnter Value of Percentage ::";
     cin >> per;
     if ( per >= 60 )
     cout << "Passed";
     return 0; // indicate that program ended successfully
} 
