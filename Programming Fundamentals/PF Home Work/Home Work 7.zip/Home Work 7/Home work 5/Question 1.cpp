#include <iostream>

using namespace std;

int main() 
{
     if ('\0')
     cout << "Truth";
     if (NULL)
     cout << "Truth";
     if (0)
     cout << "Truth";
     if (5-5)
     cout << "Truth";
     return 0;
} 

