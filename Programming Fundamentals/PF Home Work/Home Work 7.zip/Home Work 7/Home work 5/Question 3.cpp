#include <iostream>

using namespace std;

// function main begins program execution
int main()
{
     const float HIGH_SCORE = 90.0;
     float average;
     cout << "\n Enter your average Score \n";
     cin>>average;
     if (average > HIGH_SCORE)
     cout << "Congratulations!\n";
     cout << "That's a high score.\n";
     cout << "You deserve a pat on the back!\n";
     cout<<�\nOutside if structure�;
} // end function main 

