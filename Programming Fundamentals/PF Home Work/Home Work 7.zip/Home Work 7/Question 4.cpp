#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{

 int day, seed;
 cout<<"Enter value of seed: ";
 srand(time(NULL));//Taking seed as input from current time (number of seconds elapsed in your machine)
 day = rand();

 cout<<"\nValue generated from random Function";
 cout<<endl<<day<<endl;

 cout<<"Normalizing Day 1 to 7 according to our problem";
 day = (day % 7) + 1;
 cout<<endl<<day<<endl;

 if (day == 1)
 cout << "Sunday\n";
 else if (day == 2)
 cout << "Monday\n";
 else if (day == 3)
 cout << "Tuesday\n";
 else if (day == 4)
 cout << "Wednesday\n";
 else if (day == 5)
 cout << "Thursday\n";
 else if (day == 6)
 cout << "Friday\n";
 else if (day == 7)
 cout << "Saturday\n";
 ///Remember no need of default case now 
return 0;
} 
