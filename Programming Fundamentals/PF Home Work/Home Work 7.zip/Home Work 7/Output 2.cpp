#include <iostream>

using namespace std;

int main()
{
 int choice = 2;
 switch (choice) {
 default:
 cout << "\nI am in Default";
 case 1:
 cout << "\nI am in case 1";
 case 2:
 cout << "\nI am in case 2";
 case 3:
 cout << "\nI am in case 3";
 }
 return 0;
} 
