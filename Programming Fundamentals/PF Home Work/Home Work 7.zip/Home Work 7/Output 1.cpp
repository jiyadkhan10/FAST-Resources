#include <iostream>

using namespace std;

int main()
{
 int choice = 5;
 switch (choice) {
 default:
 cout << "\nI am in Default";
 case 1:
 cout << "\nI am in case 1";
 break;
 case 2:
 cout << "\nI am in case 2";
 break;
 case 3:
 cout << "\nI am in case 3";
 break;
 }
return 0;
}


