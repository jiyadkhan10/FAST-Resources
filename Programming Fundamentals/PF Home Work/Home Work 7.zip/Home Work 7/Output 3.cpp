#include <iostream>

using namespace std;

int main()
{
 float num1 = 1.1;
 double num2 = 1.1;
 if (num1 == num2)
 cout << "Stanford";
 else
 cout << "Islamabad";

return 0;
} 

