#include <iostream>

using namespace std;

int main()
{
    int i = 3, j = 3, k = 3;
    if (--i - 7 && j++ < ++k)
      cout<< ++i;
    else
    cout<< i << j << k;
    return 0;
}
