#include <iostream>

using namespace std;

int main()
{
int y = 0;
switch (y){
case 0: y = y + 5;
case 1: y = y / 2;
case 2: y = y * 3;
case 3: y = y + 10;
default: y = y%3;
}
cout << y << endl;
return 0;
}
