#include <iostream>

using namespace std;

int main()
{
    int y = 0, x = 1;
    if (y != 0);
    {
       if (x != 0);
         result = x / y;
    }
    else 
	{ 
        cout<< Error: y is equal to zero\n ; // Error because of " " is not used in this statement
    }
    return 0;
} 
