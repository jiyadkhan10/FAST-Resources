#include <iostream>

using namespace std;

int main()
{
	int num1 = 0;
    while (num1 <= 10)
    {
       cout << num1;
       num1++; 
    }
}
// There is no error in this code
