#include <iostream>

using namespace std;

int main()
{
	int num, bigNum, power, count;
    cout << "Enter an integer: ";
    cin >> num;
    cout << "What power do you want it raised to? ";
    cin >> power;
    bigNum = num;
    while (count++ < power);
    {
        bigNum *= num;
    }
     cout << "The result is "<< bigNum << endl; 
}
// There is no error in this code
