#include <iostream>

using namespace std;

int main()
{
     int num = 1;
     while ( ) // There was no condition declared in the bracket 
     {
        cout<<num;
        num1++; // num1 was not declared
     }	
}
