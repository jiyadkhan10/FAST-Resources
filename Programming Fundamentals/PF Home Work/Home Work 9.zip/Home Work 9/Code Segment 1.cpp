#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	const int MIN_NUMBER = 1, MAX_NUMBER = 10;
    int num = MIN_NUMBER;


    while (num <= MAX_NUMBER)
    {
       cout << num << setw(10) << (num * num) << endl;
       num++;
    } 

}
