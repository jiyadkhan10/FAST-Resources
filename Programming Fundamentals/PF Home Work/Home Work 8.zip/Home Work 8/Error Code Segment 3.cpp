#include <iostream>

using namespace std;

int main()
{
	int num = 1;
    while ( ) // There should be condition between the brackets
    {
       cout<<num;
       num1++; // num1 was not declared
    } 

}
