#include <iostream>

using namespace std;

int main() 
{
     int x = 1;
     while (x <= 50)
     {
       if (x % 3 == 0 || x % 5 == 0)
       cout << x << " ";
       x = x + 1;
     }
	 return 0;
} 
