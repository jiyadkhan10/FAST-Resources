#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	int i = 5;
    while (i > 0)
    {
       cout << setw(i) << "*" << endl;
       i--;
    }
    while (i < 4)
    {
      cout << setw(i+2) << "*" << endl;
      i++;
    } 
    return 0;
}
