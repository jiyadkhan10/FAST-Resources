#include <iostream>
#include <iomanip>

using namespace std;

int main()
{ 
     int a = 0;
     while (a < 100) 
	 {
        if (a % 5 == 0)
        {
            cout << "*"<<endl;
            a++;
        }
     }
     cout << '\n';  // Error because ' ' is used instead of " "

}
