#include <iostream>

using namespace std;

int main()
{
	int count = 1, total;
    while (count <= 100)
    {
      total += count;
    }
      cout << "The sum of the numbers 1-100 is ";
      cout << total << endl;
    // There is no output in this code 
}
