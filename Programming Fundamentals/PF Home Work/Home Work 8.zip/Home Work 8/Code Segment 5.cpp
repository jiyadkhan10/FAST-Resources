#include <iostream>

using namespace std;

int main() 
{
     int x = 2;
     int y = 10;

     cout << ++x * y--;
     cout << x++ * y-- << " " << --x * --y  << " " << ++x * ++y << endl;

     return 0;
} 

