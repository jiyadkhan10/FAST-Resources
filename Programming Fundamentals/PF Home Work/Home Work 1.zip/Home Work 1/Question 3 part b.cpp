#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
     cout << endl;
     cout << setw(20) << left << "Hello";
     cout << endl;
     cout << setw(20) << right << "bye";
     cout << endl;
} 
