#include <iostream>

using namespace std;

int main() 
{
     cout << sizeof(5) << endl;
     cout << sizeof('5') << endl;
     cout << sizeof("5") << endl;
     cout << sizeof("55") << endl;
     return 0;
}

