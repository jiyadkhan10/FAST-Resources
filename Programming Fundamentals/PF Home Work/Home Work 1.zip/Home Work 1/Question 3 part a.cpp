#include <iostream>
#include<iomanip>

using namespace std;

int main ()
{
     cout << endl; 
     cout << setw(20) << left << "Hello";
     cout << setw(20) << right << "bye" ;
     cout << endl;
     
     return 0;
} 
