/* This program explains how to print Pattern using setfill() and setw. */

#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
      std::cout << std::setw(10) << std::setfill('x');
      std::cout << '#' << std::endl;
      
      std::cout << std::setw(8) << std::setfill('x');
      std::cout << '#' << std::endl;
      
      std::cout << std::setw(6) << std::setfill('x');
      std::cout << '#' << std::endl;
      
      std::cout << std::setw(4) << std::setfill('x');
      std::cout << '#' << std::endl;
      
      std::cout << std::setw(2) << std::setfill('x');
      std::cout << '#' << std::endl;
      
      std::cout << '#' << std::endl;
}
