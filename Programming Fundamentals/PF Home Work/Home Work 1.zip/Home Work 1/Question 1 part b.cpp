#include <iostream>
using namespace std;
int main ()
{
     int a = 10;
     short b = 10;
     long c = 10;
     float d = 10.0;
     double e = 10.0;
     long double f = 10.0;
     bool g = true;
     
     cout << "Value of Integer a is " << a << " size is " << sizeof(a) << endl;
     cout << "Value of short c is " << b << " size is " << sizeof(b) << endl;
     cout << "Value of long c is " << c << " size is " << sizeof(c) << endl; 
     cout << "Size of integer Literal is 10 and its size is " << sizeof(10) << endl;
     cout << "Value of Float d is " << d << " size is " << sizeof(d) << endl;
     cout << "Value of double e is " << e <<" size is " << sizeof(e) << endl;
     cout << "Value of long double f is " << f << " size is " << sizeof(f) << endl;
     cout << "Size of Float Literal is 10.0 and its size is " << sizeof(10.0) << endl;
     cout << "Value of boolean g is " << g << " size is " << sizeof(g) << endl;
     cout << "Size of boolean literal \"true\" is " << sizeof(true) << endl;
     cout << "Size of literal character \'A\' is " << sizeof('A') << endl;
     cout << "Size of string literal \"A\" is is " << sizeof("A") << endl;
     
     return 0;
} 

