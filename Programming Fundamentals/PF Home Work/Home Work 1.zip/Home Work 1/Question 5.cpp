#include <iostream>
#include<iomanip>

using namespace std;

int main ()
{
     float f = 12.5544;
     
     cout << setprecision(6) << fixed << f << endl;
     cout << setprecision(5) << fixed << f << endl;
     cout << setprecision(4) << fixed << f << endl;
     cout << setprecision(3) << fixed << f << endl;
     cout << setprecision(2) << fixed << f << endl;
     cout << setprecision(1) << fixed << f << endl;
     cout << endl;
     
     return 0;
}
