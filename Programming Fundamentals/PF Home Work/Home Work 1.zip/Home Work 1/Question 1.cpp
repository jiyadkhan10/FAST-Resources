#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
    cout << "\aHello \r tell\a"<<endl;
    return 0;
} 
