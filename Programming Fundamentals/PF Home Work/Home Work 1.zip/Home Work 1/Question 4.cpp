#include <iostream>
#include<iomanip>

using namespace std;

int main ()
{
     float f = 12.5544; 
     
     cout << setprecision(6) << f << endl;
     cout << setprecision(5) << f << endl;
     cout << setprecision(4) << f << endl;
     cout << setprecision(3) << f << endl;
     cout << setprecision(2) << f << endl;
     cout << setprecision(1) << f<< endl;
     cout << endl;
     
     return 0;
} 

