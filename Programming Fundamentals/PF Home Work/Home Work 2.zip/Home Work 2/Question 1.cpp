#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
     const double I; // double I
     int n;
     I = 3.14159265358979;
     cout << I * I;
} 
