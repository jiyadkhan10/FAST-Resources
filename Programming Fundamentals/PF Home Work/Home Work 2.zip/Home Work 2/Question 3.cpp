#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
      int x = 4;
      int y = 6;
      double z = 7;
      int num2 = z / y * x / 2 * 10 + (y * x + 2) / z;
      cout << "\n\tThe value of expression 1 is " << num2 << "." << endl;
      double num3 = z * x + y * z / 16;
      cout << "\n\tThe value of expression 2 is " << num3 << "." << endl;
} 
