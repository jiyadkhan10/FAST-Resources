#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
      cout << setprecision(6);
      double d = 33.00;
      int x = 15;
      cout << d / x << endl;
      cout << setprecision(6) << fixed;
      cout << d / x << endl;
      
      return 0;
} 
