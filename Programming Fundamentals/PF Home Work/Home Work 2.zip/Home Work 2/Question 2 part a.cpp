#include <iostream>

using namespace std;

int main ()
{
      int a = 10;
      short b = 10;
      long c = 10;
      
      cout << "Value of Integer a is " << a << " size is " << sizeof(a) << endl;
      cout << "Value of short c is " << b << " size is " << sizeof(b) << endl;
      cout << "Value of long c is " << c << " size is " << sizeof(c) << endl;
      cout << "Size of integer Literal is 10 and its size is " << sizeof(10) << endl;
      
      return 0;
} 

