#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
      unsigned short j = -2;
      
      cout <<"\nValue of \"j\" is = " << j << endl;
      
      return 0; 
} 
