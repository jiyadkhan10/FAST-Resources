#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
      short i = 32769;
      unsigned short j = 32769;
      
      cout <<"\nValue of \"i\" is = "<< i <<endl;
      cout <<"\nValue of \"j\" is = " << j << endl;
      
      return 0;
} 

