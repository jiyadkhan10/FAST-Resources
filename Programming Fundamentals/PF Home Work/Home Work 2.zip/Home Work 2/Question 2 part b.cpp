#include <iostream>

using namespace std;

int main ()
{
      float a = 10.01;
      double b = 10.01;
      long double c = 10.01;
      
      cout << "Value of Integer a is " << a << " size is " << sizeof(a) << endl;
      cout << "Value of short c is " << b << " size is " << sizeof(b) << endl;
      cout << "Value of long c is " << c << " size is " << sizeof(c) << endl; 
      cout << "Size of integer Literal is 10 and its size is " << sizeof(10.01) << endl;
      
      return 0;
 } 
