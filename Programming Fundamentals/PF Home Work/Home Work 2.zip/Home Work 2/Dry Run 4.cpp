#include <iostream>
#include<iomanip>
using namespace std;
int main() 
{
    int a = 3;
	int b = 26;
	
    a = a / b;
    b = b - a;
    b = b / 2;
    a = a * b;
    
    cout << "\n First Modified value : " << a;
    cout << "\n Second Modified value: " << b;
} 
