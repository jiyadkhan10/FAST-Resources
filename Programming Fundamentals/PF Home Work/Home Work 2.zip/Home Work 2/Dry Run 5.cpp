#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
      int z = 5;
	  int j = 7; 
	  int k = 6;
	  int n = 3;
	  
      cout << z + j % k + k * n - 15 << endl;
      cout << z % n + 5 << endl;
} 

