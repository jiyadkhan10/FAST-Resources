#include <iostream>
#include<iomanip>

using namespace std;

int main() 
{
      cout << setprecision(4);
      double d = 3.00;
      int x = 12;
      cout << d / x << endl;
      cout << setprecision(4) << fixed;
      cout << d / x << endl;
      
      return 0; 
}
