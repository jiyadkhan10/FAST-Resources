#include <iostream>

using namespace std;

// function main begins program execution
int main()
{
	bool trueValue, falseValue;
	int x = 5, y = 10;
	trueValue = x < y;
	falseValue = y == x;
	cout << "True is " << trueValue << endl;
	cout << "False is " << falseValue << endl;
	return 0;
} // extra closed bracket 

} //end function main
