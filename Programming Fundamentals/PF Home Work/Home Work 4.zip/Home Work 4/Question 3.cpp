#include <iostream>

using namespace std;

int main()
{
	int a = 5, b = 8;
	bool check = a < b;
	cout << endl;
	cout << "First value is a " << a << "Second value is b " << b << endl;
	cout << endl << "checking \ " a < b \ " " << (a < b) << endl; // '\' should be written in " " & expected ';' before 'a'
	cout << endl << "checking \ " a > b \ " " << (a > b) << endl; // '\' should be written in " " & expected ';' before 'a'
	cout << endl << "checking \ " a <= b \ " " << (a <= b) << endl; // '\' should be written in " " & expected ';' before 'a'
	cout << endl << "checking \ " a >= b \ " " << (a >= b) << endl; // '\' should be written in " " & expected ';' before 'a'
	cout << endl << "checking \ " a == b \ " " << (a == b) << endl; // '\' should be written in " " & expected ';' before 'a'
	cout << endl << "checking \ " a != b \ " " << (a != b) << endl; // '\' should be written in " " & expected ';' before 'a'
	cout << endl << "Printing bool variable check = " << check << endl;
	return 0;
}
