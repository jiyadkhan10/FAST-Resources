#include <iostream>

using namespace std;

int main ()
{
	int a = 5;
	int b = 8;
	cout << a < b; //cout << a << b;
	return 0;
}
