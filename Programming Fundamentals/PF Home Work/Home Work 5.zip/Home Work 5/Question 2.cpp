#include <iostream>

using namespace std;

// function main begins program execution
int main()
{
 
     int a;

     cout << "\nEnetr a value";
     cin >> a;
     if (a = 10)
     cout << "\nvalue is equal to 10";

} // end function main 
