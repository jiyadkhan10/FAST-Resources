#include <iostream>

using namespace std;

int main() 
{

     float f = 0.1f;
     cout <<setprecision(16)<< f;  // 'setprecision was not declared in this scope
     return 0;
}
