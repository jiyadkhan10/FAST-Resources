#include <iostream>

using namespace std;
 
int main()
{
     int number;
     cout << "Enter an integer and I will tell you if it\n";
     cout << "is odd or even. ";
     cin >> number;
     if (number % 2 == 1)//mixed expression/test
     cout << number << " is Odd.\n";

     return 0;
} 

