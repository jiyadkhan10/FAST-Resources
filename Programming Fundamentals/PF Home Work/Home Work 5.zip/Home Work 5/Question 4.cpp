//�..4.cpp��
#include <iostream>

using namespace std;

// function main begins program execution
int main ()
{

     float check = 1.2;
 
     if (check == 1.2)
     {
      cout<<"Everything is OK";
     }
} // end function main 
