#include <iostream>

using namespace std;

int main()
{ 
      cout << (2.2 | 1.1);
} 
