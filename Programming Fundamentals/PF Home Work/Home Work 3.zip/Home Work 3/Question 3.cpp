#include <iostream>

using namespace std;

int main ()
{ 
    short alpha = 15;
    short beta = 245;
    cout << endl;
    cout << (alpha | beta) << endl;
    cout << (alpha & beta) << endl;
    cout << ~alpha << endl;
    cout << ~beta << endl;
    cout << (alpha ^ beta) << endl;
    return 0;
}
