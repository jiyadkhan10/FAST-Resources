#include <iostream>

using namespace std;

int main ()
{
    short a = 1;
    a = a << 1;
    cout << a;
    a = a << 1;
    cout << a;
    return 0;
} 
