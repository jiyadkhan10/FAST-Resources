#include <iostream>

using namespace std;

int main() 
{
     short a = 1;
     a = (a << 18);
     cout << a;
} 

