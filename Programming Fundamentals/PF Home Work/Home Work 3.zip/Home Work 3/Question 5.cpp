#include <iostream>

using namespace std;

int main ()
{
    short a = 1; 
    a = a << 15;
    cout << a;
    return 0;
} 

