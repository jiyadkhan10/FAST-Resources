#include <iostream>

using namespace std;

int main ()
{
    short a = 0;
    cout << ~a;
    return 0;
} 
