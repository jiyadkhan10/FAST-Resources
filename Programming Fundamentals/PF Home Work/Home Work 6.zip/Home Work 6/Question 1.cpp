#include <iostream>

using namespace std;

// function main begins program execution
int main() 
{
    if (cout << 0)
    {
      cout << "Hello";
    }
    else
    {
      cout << "Not Hello";
    }
    return 0;
} 
